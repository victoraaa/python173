#! /bin/bash

echo $@ | racket python-main.rkt --python-path /course/cs173/python/Python-3.2.3/python --interp
