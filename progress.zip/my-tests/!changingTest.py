y=1
f = lambda x: y
___assertEqual(f(10),1)